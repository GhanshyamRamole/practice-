"""
backend/routers/chat.py
ChatOps interface — powers the "Why did deployment fail?" dashboard chat.
Routes questions to the right agent(s) and composes a unified answer.
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional
import json

from agents.llm_client import LLMClient
from agents.specialists import LogAnalysisAgent, MetricsAgent, RCAAgent

router = APIRouter()

# Shared LLM client (swap provider via env var LLM_PROVIDER=claude|openai|bedrock)
import os
llm = LLMClient(provider=os.getenv("LLM_PROVIDER", "claude"))

# Agent instances
log_agent     = LogAnalysisAgent(llm, {})
metrics_agent = MetricsAgent(llm, {})
rca_agent     = RCAAgent(llm, {})


CHAT_SYSTEM = """You are an expert DevOps AI assistant. You have access to real-time 
platform data (logs, metrics, incidents). Answer questions clearly and concisely.
When asked about failures, correlate log errors + metric anomalies + recent deployments.
When asked about infrastructure, refer to current Terraform state and CloudWatch alarms.
Always end with a concrete recommended action.
Format: plain prose, use bullet points for multi-step answers. Max 200 words."""


class ChatRequest(BaseModel):
    message: str
    context: Optional[dict] = None   # can carry recent logs, metrics, incident ID
    conversation_id: Optional[str] = None


class ChatResponse(BaseModel):
    reply: str
    sources: list[str]
    agent_results: Optional[dict] = None


@router.post("/", response_model=ChatResponse)
async def chat(req: ChatRequest):
    """
    Primary ChatOps endpoint.
    POST /api/v1/chat/
    Body: { "message": "Why did deployment fail?", "context": {...} }
    """
    message_lower = req.message.lower()

    # Route to specialist agents if the question implies live data analysis
    agent_results = {}
    sources = ["LLM reasoning"]

    if any(kw in message_lower for kw in ["fail", "error", "crash", "down", "alert", "why"]):
        # Pull in log + metrics analysis if context provides them
        if req.context and req.context.get("log_lines"):
            log_result = await log_agent.run({
                "log_lines": req.context["log_lines"],
                "service":   req.context.get("service", "unknown"),
                "time_window": "10m",
            })
            agent_results["log_analysis"] = log_result.raw_output
            sources.append("Log Analysis Agent")

        if req.context and req.context.get("metrics"):
            metrics_result = await metrics_agent.run({
                "metrics":    req.context["metrics"],
                "service":    req.context.get("service", "unknown"),
                "thresholds": req.context.get("thresholds", {}),
            })
            agent_results["metrics_analysis"] = metrics_result.raw_output
            sources.append("Metrics Agent")

    # Compose enriched prompt with agent context
    enriched_context = ""
    if agent_results:
        enriched_context = f"\n\nAgent findings:\n{json.dumps(agent_results, indent=2)}"

    user_prompt = f"User question: {req.message}{enriched_context}"

    try:
        reply = await llm.complete(CHAT_SYSTEM, user_prompt)
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"LLM unavailable: {str(e)}")

    return ChatResponse(reply=reply, sources=sources, agent_results=agent_results or None)
