"""
backend/routers/pipeline.py
Self-healing CI/CD pipeline endpoint.
Receives pipeline failure webhooks from GitHub Actions / Jenkins,
runs AI root cause analysis, auto-retries or suggests fixes.
"""

from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel
from typing import Optional
import httpx, os, json, asyncio

from agents.llm_client import LLMClient
from agents.specialists import LogAnalysisAgent, RCAAgent

router = APIRouter()
llm = LLMClient(provider=os.getenv("LLM_PROVIDER", "claude"))
log_agent = LogAnalysisAgent(llm, {})
rca_agent = RCAAgent(llm, {})

GITHUB_TOKEN = os.getenv("GITHUB_TOKEN", "")


class PipelineFailureEvent(BaseModel):
    run_id: str
    repo: str           # e.g. "org/repo"
    branch: str
    workflow: str
    failed_step: str
    log_lines: list[str]
    attempt: int = 1


class PipelineFixResponse(BaseModel):
    run_id: str
    rca_summary: str
    fix_steps: list[str]
    auto_retried: bool
    retry_run_id: Optional[str] = None


@router.post("/failure", response_model=PipelineFixResponse)
async def handle_pipeline_failure(event: PipelineFailureEvent, bg: BackgroundTasks):
    """
    POST /api/v1/pipeline/failure
    Called by GitHub Actions webhook on job failure.
    Runs AI RCA and optionally re-triggers the run.
    """
    # Step 1: Log analysis
    log_result = await log_agent.run({
        "log_lines":   event.log_lines,
        "service":     event.workflow,
        "time_window": "current run",
    })

    # Step 2: RCA
    rca_result = await rca_agent.run({
        "incident_description": f"CI/CD failure in {event.workflow} step '{event.failed_step}' on {event.branch}",
        "log_analysis":  log_result.raw_output,
        "metrics_analysis": {},
        "traces": [],
    })

    # Step 3: Auto-retry if high confidence and not a human-escalation case
    auto_retried = False
    retry_run_id = None

    if (
        rca_result.confidence >= 0.75
        and not rca_result.raw_output.get("escalate_human")
        and event.attempt < 3
        and GITHUB_TOKEN
    ):
        retry_run_id = await _trigger_github_rerun(event.repo, event.run_id)
        auto_retried = bool(retry_run_id)

    return PipelineFixResponse(
        run_id=event.run_id,
        rca_summary=rca_result.summary,
        fix_steps=rca_result.raw_output.get("fix_steps", []),
        auto_retried=auto_retried,
        retry_run_id=retry_run_id,
    )


async def _trigger_github_rerun(repo: str, run_id: str) -> Optional[str]:
    """Re-trigger a failed GitHub Actions run via API."""
    url = f"https://api.github.com/repos/{repo}/actions/runs/{run_id}/rerun"
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.post(
                url,
                headers={"Authorization": f"Bearer {GITHUB_TOKEN}", "Accept": "application/vnd.github+json"},
            )
            if resp.status_code == 201:
                return f"rerun-{run_id}"
    except Exception:
        pass
    return None
