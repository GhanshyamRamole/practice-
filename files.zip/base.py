"""
agents/base.py — Base class for all DevOps AI agents.
Each agent has: goal, inputs, outputs, decision logic, short-term memory.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any
import uuid


@dataclass
class AgentMemory:
    """Short-term rolling memory — last N observations per agent."""
    observations: list[dict] = field(default_factory=list)
    max_size: int = 50

    def add(self, entry: dict):
        self.observations.append({"timestamp": datetime.utcnow().isoformat(), **entry})
        if len(self.observations) > self.max_size:
            self.observations.pop(0)

    def recent(self, n: int = 10) -> list[dict]:
        return self.observations[-n:]


@dataclass
class AgentResult:
    agent: str
    run_id: str
    status: str          # "success" | "warning" | "failure" | "escalate"
    summary: str
    actions_taken: list[str]
    raw_output: dict
    confidence: float    # 0.0 – 1.0
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())


class BaseAgent(ABC):
    """
    All agents extend this. Enforces: goal, run(), _reason(), _act().
    """
    goal: str = "undefined"

    def __init__(self, llm_client, config: dict):
        self.llm = llm_client
        self.config = config
        self.memory = AgentMemory()
        self.name = self.__class__.__name__

    async def run(self, inputs: dict) -> AgentResult:
        run_id = str(uuid.uuid4())[:8]
        self.memory.add({"run_id": run_id, "inputs": inputs})
        analysis = await self._reason(inputs)
        actions = await self._act(analysis, inputs)
        result = AgentResult(
            agent=self.name,
            run_id=run_id,
            status=analysis.get("status", "unknown"),
            summary=analysis.get("summary", ""),
            actions_taken=actions,
            raw_output=analysis,
            confidence=analysis.get("confidence", 0.5),
        )
        self.memory.add({"run_id": run_id, "result": result.status})
        return result

    @abstractmethod
    async def _reason(self, inputs: dict) -> dict:
        """Call LLM to analyze inputs. Return structured analysis."""

    @abstractmethod
    async def _act(self, analysis: dict, inputs: dict) -> list[str]:
        """Execute actions based on analysis. Return list of action descriptions."""
