"""
agents/specialists.py
Six production-grade AI agents for the Agentic DevOps Platform.
Each agent: goal → inputs → LLM reasoning → structured actions.
"""

import json
import re
import httpx
from agents.base import BaseAgent


# ─────────────────────────────────────────────────────────────────────────────
# 1. LOG ANALYSIS AGENT
# ─────────────────────────────────────────────────────────────────────────────

class LogAnalysisAgent(BaseAgent):
    """
    Goal: Parse logs from ELK/Loki, identify error patterns, extract signals.
    Inputs:  log_lines (list[str]), service (str), time_window (str)
    Outputs: error_patterns, anomalies, severity, recommended_action
    """
    goal = "Identify error patterns and anomalies in service logs"

    SYSTEM = """You are a senior SRE. Analyze the provided log lines and return JSON only:
{
  "status": "ok|warning|failure|escalate",
  "confidence": 0.0-1.0,
  "summary": "one sentence",
  "error_patterns": ["list of distinct error patterns"],
  "anomalies": ["unusual events detected"],
  "root_cause_hypothesis": "short hypothesis or null",
  "recommended_action": "specific next step"
}"""

    async def _reason(self, inputs: dict) -> dict:
        log_sample = "\n".join(inputs.get("log_lines", [])[-200:])
        prompt = f"Service: {inputs.get('service', 'unknown')}\nWindow: {inputs.get('time_window', '5m')}\n\nLogs:\n{log_sample}"
        resp = await self.llm.complete(self.SYSTEM, prompt)
        return self._parse_json(resp)

    async def _act(self, analysis: dict, inputs: dict) -> list[str]:
        actions = []
        if analysis.get("status") in ("failure", "escalate"):
            actions.append(f"[LogAgent] Triggered alert: {analysis.get('summary')}")
            actions.append("[LogAgent] Published event: log.failure to event bus")
        if analysis.get("root_cause_hypothesis"):
            actions.append(f"[LogAgent] RCA hypothesis forwarded to RCA Agent")
        return actions

    def _parse_json(self, text: str) -> dict:
        try:
            return json.loads(re.search(r'\{.*\}', text, re.DOTALL).group())
        except Exception:
            return {"status": "warning", "summary": text[:200], "confidence": 0.3,
                    "error_patterns": [], "anomalies": [], "recommended_action": "manual review"}


# ─────────────────────────────────────────────────────────────────────────────
# 2. METRICS ANALYSIS AGENT
# ─────────────────────────────────────────────────────────────────────────────

class MetricsAgent(BaseAgent):
    """
    Goal: Query Prometheus, detect anomalies, predict failures via threshold + LLM.
    Inputs:  metrics (dict of metric_name → time_series), service, thresholds
    Outputs: anomalies, prediction, severity
    """
    goal = "Detect metric anomalies and predict failures before they occur"

    SYSTEM = """You are an SRE metrics expert. Given metric time-series, return JSON only:
{
  "status": "ok|warning|failure|escalate",
  "confidence": 0.0-1.0,
  "summary": "one sentence",
  "anomalies": [{"metric": "...", "value": 0.0, "threshold": 0.0, "severity": "..."}],
  "prediction": "predicted state in next 15 min",
  "recommended_action": "specific next step"
}"""

    async def _reason(self, inputs: dict) -> dict:
        metrics_str = json.dumps(inputs.get("metrics", {}), indent=2)
        thresholds_str = json.dumps(inputs.get("thresholds", {}), indent=2)
        prompt = f"Service: {inputs.get('service')}\nThresholds: {thresholds_str}\nMetrics:\n{metrics_str}"
        resp = await self.llm.complete(self.SYSTEM, prompt)
        return self._parse_json(resp)

    async def _act(self, analysis: dict, inputs: dict) -> list[str]:
        actions = []
        for anomaly in analysis.get("anomalies", []):
            if anomaly.get("severity") in ("critical", "high"):
                actions.append(f"[MetricsAgent] Alert fired: {anomaly['metric']} = {anomaly['value']}")
        if analysis.get("status") == "escalate":
            actions.append("[MetricsAgent] Escalated to RCA Agent")
        return actions

    def _parse_json(self, text: str) -> dict:
        try:
            return json.loads(re.search(r'\{.*\}', text, re.DOTALL).group())
        except Exception:
            return {"status": "warning", "summary": text[:200], "confidence": 0.3,
                    "anomalies": [], "prediction": "unknown", "recommended_action": "manual review"}


# ─────────────────────────────────────────────────────────────────────────────
# 3. ROOT CAUSE ANALYSIS (RCA) AGENT
# ─────────────────────────────────────────────────────────────────────────────

class RCAAgent(BaseAgent):
    """
    Goal: Correlate log errors, metric anomalies, traces → identify failure origin.
    Inputs:  log_analysis (dict), metrics_analysis (dict), traces (list), incident_description (str)
    Outputs: root_cause, contributing_factors, fix_steps, escalate_human (bool)
    """
    goal = "Correlate signals across logs, metrics, traces to find root cause"

    SYSTEM = """You are a principal SRE performing root cause analysis. 
Correlate all provided signals and return JSON only:
{
  "status": "resolved|escalate",
  "confidence": 0.0-1.0,
  "summary": "one sentence root cause",
  "root_cause": "detailed root cause",
  "contributing_factors": ["list"],
  "fix_steps": ["ordered list of fix steps"],
  "escalate_human": true/false,
  "estimated_fix_time": "e.g. 5 minutes"
}"""

    async def _reason(self, inputs: dict) -> dict:
        payload = {
            "incident": inputs.get("incident_description", ""),
            "log_signals": inputs.get("log_analysis", {}),
            "metric_signals": inputs.get("metrics_analysis", {}),
            "traces": inputs.get("traces", [])[:20],
            "memory": self.memory.recent(5),
        }
        resp = await self.llm.complete(self.SYSTEM, json.dumps(payload, indent=2))
        return self._parse_json(resp)

    async def _act(self, analysis: dict, inputs: dict) -> list[str]:
        actions = []
        actions.append(f"[RCAAgent] Root cause identified: {analysis.get('root_cause', 'unknown')}")
        if analysis.get("fix_steps"):
            actions.append(f"[RCAAgent] Fix plan dispatched to DeploymentAgent ({len(analysis['fix_steps'])} steps)")
        if analysis.get("escalate_human"):
            actions.append("[RCAAgent] PagerDuty escalation triggered — requires human intervention")
        return actions

    def _parse_json(self, text: str) -> dict:
        try:
            return json.loads(re.search(r'\{.*\}', text, re.DOTALL).group())
        except Exception:
            return {"status": "escalate", "summary": "RCA parse error", "confidence": 0.2,
                    "root_cause": "unknown", "contributing_factors": [], "fix_steps": [],
                    "escalate_human": True, "estimated_fix_time": "unknown"}


# ─────────────────────────────────────────────────────────────────────────────
# 4. DEPLOYMENT AGENT
# ─────────────────────────────────────────────────────────────────────────────

class DeploymentAgent(BaseAgent):
    """
    Goal: Choose strategy, execute Kubernetes rollout, auto-rollback on failure.
    Inputs:  app_name, image_tag, namespace, fix_steps (from RCA), current_replicas
    Outputs: strategy_chosen, rollout_result, rollback_triggered
    """
    goal = "Safely deploy or roll back applications on Kubernetes"

    SYSTEM = """You are a senior platform engineer. Choose the safest deployment strategy.
Return JSON only:
{
  "status": "success|rollback|failure",
  "confidence": 0.0-1.0,
  "summary": "one sentence",
  "strategy": "rolling|blue_green|canary",
  "canary_weight": 10,
  "rollback_threshold": "5xx error rate > 1%",
  "kubectl_commands": ["ordered list of kubectl commands"],
  "monitoring_check": "prometheus query to validate success"
}"""

    async def _reason(self, inputs: dict) -> dict:
        resp = await self.llm.complete(self.SYSTEM, json.dumps(inputs, indent=2))
        return self._parse_json(resp)

    async def _act(self, analysis: dict, inputs: dict) -> list[str]:
        actions = []
        strategy = analysis.get("strategy", "rolling")
        app = inputs.get("app_name", "app")
        tag = inputs.get("image_tag", "latest")
        ns = inputs.get("namespace", "default")

        actions.append(f"[DeployAgent] Strategy selected: {strategy}")
        actions.append(f"[DeployAgent] kubectl set image deployment/{app} {app}={app}:{tag} -n {ns}")

        if strategy == "canary":
            w = analysis.get("canary_weight", 10)
            actions.append(f"[DeployAgent] Canary weight set to {w}%")
            actions.append(f"[DeployAgent] Monitoring: {analysis.get('monitoring_check', '')}")

        if analysis.get("status") == "rollback":
            actions.append(f"[DeployAgent] Rollback triggered: kubectl rollout undo deployment/{app} -n {ns}")

        return actions

    def _parse_json(self, text: str) -> dict:
        try:
            return json.loads(re.search(r'\{.*\}', text, re.DOTALL).group())
        except Exception:
            return {"status": "failure", "summary": "parse error", "confidence": 0.2,
                    "strategy": "rolling", "kubectl_commands": [], "rollback_threshold": ">1% errors"}


# ─────────────────────────────────────────────────────────────────────────────
# 5. SECURITY AGENT
# ─────────────────────────────────────────────────────────────────────────────

class SecurityAgent(BaseAgent):
    """
    Goal: Scan container images and IaC for CVEs, suggest and apply patches.
    Inputs:  image (str), terraform_plan (str, optional), scan_results (dict from Trivy/Snyk)
    Outputs: vulnerabilities, patch_commands, auto_remediated
    """
    goal = "Detect vulnerabilities and auto-remediate where safe"

    SYSTEM = """You are a DevSecOps engineer. Analyze scan results and return JSON only:
{
  "status": "clean|warning|critical",
  "confidence": 0.0-1.0,
  "summary": "one sentence",
  "vulnerabilities": [
    {"cve": "...", "severity": "CRITICAL|HIGH|MEDIUM|LOW", "package": "...", "fix_version": "..."}
  ],
  "patch_commands": ["ordered remediation steps"],
  "auto_remediate": true/false,
  "estimated_risk": "high|medium|low"
}"""

    async def _reason(self, inputs: dict) -> dict:
        resp = await self.llm.complete(self.SYSTEM, json.dumps(inputs, indent=2))
        return self._parse_json(resp)

    async def _act(self, analysis: dict, inputs: dict) -> list[str]:
        actions = []
        criticals = [v for v in analysis.get("vulnerabilities", []) if v.get("severity") == "CRITICAL"]
        if criticals:
            actions.append(f"[SecurityAgent] {len(criticals)} CRITICAL CVEs found — blocking deployment")
        if analysis.get("auto_remediate"):
            for cmd in analysis.get("patch_commands", []):
                actions.append(f"[SecurityAgent] Executing: {cmd}")
        return actions

    def _parse_json(self, text: str) -> dict:
        try:
            return json.loads(re.search(r'\{.*\}', text, re.DOTALL).group())
        except Exception:
            return {"status": "warning", "summary": "parse error", "confidence": 0.2,
                    "vulnerabilities": [], "patch_commands": [], "auto_remediate": False}


# ─────────────────────────────────────────────────────────────────────────────
# 6. INFRASTRUCTURE AGENT
# ─────────────────────────────────────────────────────────────────────────────

class InfraAgent(BaseAgent):
    """
    Goal: Detect infra failures (EC2, RDS, EKS nodes) and auto-recreate via Terraform/Lambda.
    Inputs:  cloudwatch_alarms (list), resource_inventory (dict), terraform_state_summary (str)
    Outputs: failed_resources, remediation_plan, terraform_commands
    """
    goal = "Detect and auto-recover failed AWS infrastructure resources"

    SYSTEM = """You are a cloud infrastructure engineer. Analyze alarms and return JSON only:
{
  "status": "healthy|degraded|critical",
  "confidence": 0.0-1.0,
  "summary": "one sentence",
  "failed_resources": [{"resource_id": "...", "type": "ec2|rds|eks_node", "reason": "..."}],
  "remediation_plan": ["ordered steps"],
  "terraform_commands": ["terraform commands to restore"],
  "estimated_recovery_time": "e.g. 3 minutes"
}"""

    async def _reason(self, inputs: dict) -> dict:
        resp = await self.llm.complete(self.SYSTEM, json.dumps(inputs, indent=2))
        return self._parse_json(resp)

    async def _act(self, analysis: dict, inputs: dict) -> list[str]:
        actions = []
        for resource in analysis.get("failed_resources", []):
            actions.append(f"[InfraAgent] Detected failure: {resource['resource_id']} ({resource['type']})")
        for cmd in analysis.get("terraform_commands", [])[:5]:
            actions.append(f"[InfraAgent] Executing: {cmd}")
        return actions

    def _parse_json(self, text: str) -> dict:
        try:
            return json.loads(re.search(r'\{.*\}', text, re.DOTALL).group())
        except Exception:
            return {"status": "degraded", "summary": "parse error", "confidence": 0.2,
                    "failed_resources": [], "remediation_plan": [], "terraform_commands": []}
