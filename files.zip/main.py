"""
Agentic AI DevOps Platform — FastAPI Backend
Orchestrates all AI agents: log analysis, metrics, RCA, deployment, security.
"""

from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from contextlib import asynccontextmanager
import logging

from routers import chat, pipeline, deployment, security, rca, infra

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("AI DevOps Platform starting up...")
    yield
    logger.info("AI DevOps Platform shutting down...")


app = FastAPI(
    title="Agentic AI DevOps Platform",
    description="Self-healing, AI-powered DevOps orchestration platform",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "https://your-domain.com"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(chat.router,       prefix="/api/v1/chat",       tags=["ChatOps"])
app.include_router(pipeline.router,   prefix="/api/v1/pipeline",   tags=["CI/CD"])
app.include_router(deployment.router, prefix="/api/v1/deployment",  tags=["Deployment"])
app.include_router(security.router,   prefix="/api/v1/security",   tags=["DevSecOps"])
app.include_router(rca.router,        prefix="/api/v1/rca",         tags=["Root Cause Analysis"])
app.include_router(infra.router,      prefix="/api/v1/infra",       tags=["Infrastructure"])


@app.get("/health")
async def health():
    return {"status": "ok", "platform": "AI DevOps Platform v1.0.0"}
