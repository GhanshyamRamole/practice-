"""
agents/llm_client.py
Unified LLM client. Swap between Claude, OpenAI, or AWS Bedrock via config.
"""

import os
import json
import httpx
from typing import Literal


class LLMClient:
    """
    Wraps Claude (Anthropic), OpenAI GPT-4, or AWS Bedrock.
    Usage:
        client = LLMClient(provider="claude")
        response = await client.complete(system_prompt, user_prompt)
    """

    def __init__(
        self,
        provider: Literal["claude", "openai", "bedrock"] = "claude",
        model: str | None = None,
        max_tokens: int = 1024,
    ):
        self.provider = provider
        self.max_tokens = max_tokens
        self.model = model or self._default_model(provider)

    def _default_model(self, provider: str) -> str:
        return {
            "claude": "claude-sonnet-4-20250514",
            "openai": "gpt-4o",
            "bedrock": "anthropic.claude-3-5-sonnet-20241022-v2:0",
        }.get(provider, "claude-sonnet-4-20250514")

    async def complete(self, system: str, user: str) -> str:
        if self.provider == "claude":
            return await self._call_claude(system, user)
        elif self.provider == "openai":
            return await self._call_openai(system, user)
        elif self.provider == "bedrock":
            return await self._call_bedrock(system, user)
        raise ValueError(f"Unknown provider: {self.provider}")

    # ── Claude (Anthropic) ──────────────────────────────────────────────────

    async def _call_claude(self, system: str, user: str) -> str:
        async with httpx.AsyncClient(timeout=60) as client:
            resp = await client.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": os.environ["ANTHROPIC_API_KEY"],
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
                json={
                    "model": self.model,
                    "max_tokens": self.max_tokens,
                    "system": system,
                    "messages": [{"role": "user", "content": user}],
                },
            )
            resp.raise_for_status()
            return resp.json()["content"][0]["text"]

    # ── OpenAI ──────────────────────────────────────────────────────────────

    async def _call_openai(self, system: str, user: str) -> str:
        async with httpx.AsyncClient(timeout=60) as client:
            resp = await client.post(
                "https://api.openai.com/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {os.environ['OPENAI_API_KEY']}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": self.model,
                    "max_tokens": self.max_tokens,
                    "messages": [
                        {"role": "system", "content": system},
                        {"role": "user", "content": user},
                    ],
                },
            )
            resp.raise_for_status()
            return resp.json()["choices"][0]["message"]["content"]

    # ── AWS Bedrock ─────────────────────────────────────────────────────────

    async def _call_bedrock(self, system: str, user: str) -> str:
        import boto3, json as _json
        bedrock = boto3.client("bedrock-runtime", region_name=os.environ.get("AWS_REGION", "us-east-1"))
        body = _json.dumps({
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": self.max_tokens,
            "system": system,
            "messages": [{"role": "user", "content": user}],
        })
        resp = bedrock.invoke_model(modelId=self.model, body=body)
        return _json.loads(resp["body"].read())["content"][0]["text"]
