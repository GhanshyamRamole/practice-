# Agentic AI DevOps Platform

A **self-operating DevOps platform** where AI agents monitor systems, detect failures,
perform root cause analysis, fix issues automatically, and deploy applications intelligently.

## Architecture

```
Data Sources (Prometheus, ELK, CloudWatch, GitHub)
              ↓
        Event Bus (Kafka / SNS+SQS)
              ↓
    ┌─────────────────────────────────┐
    │         AI Agent Layer          │
    │  Log · Metrics · RCA            │
    │  Deploy · Security · Infra      │
    └─────────────────────────────────┘
              ↓
    LLM Orchestrator (Claude / GPT-4)
              ↓
    Action Layer: K8s · CI/CD · Terraform
              ↓
    React Dashboard + FastAPI ChatOps
```

## Project Structure

```
ai-devops-platform/
├── agents/
│   ├── base.py              # BaseAgent + AgentMemory
│   ├── specialists.py       # 6 AI agents
│   └── llm_client.py        # Claude / OpenAI / Bedrock wrapper
├── backend/
│   ├── main.py              # FastAPI app
│   └── routers/
│       ├── chat.py          # ChatOps endpoint
│       ├── pipeline.py      # CI/CD failure webhook
│       ├── deployment.py    # Deployment control
│       ├── rca.py           # Root cause analysis
│       ├── security.py      # DevSecOps scanning
│       └── infra.py         # Infrastructure recovery
├── terraform/
│   └── modules/
│       ├── vpc/             # Production VPC (3 AZs)
│       ├── eks/             # EKS cluster + node groups
│       └── alb/             # Application Load Balancer
├── kubernetes/
│   └── deployments/
│       └── ai-devops-platform.yaml   # Deployment, HPA, RBAC, NetworkPolicy
├── pipelines/
│   └── self-healing-ci.yml  # GitHub Actions with AI webhook integration
├── monitoring/
│   └── prometheus-rules.yaml        # Alerting rules (6 categories)
└── docs/
    └── agent-design.md
```

## The 6 AI Agents

| Agent | Goal | Key Inputs | Key Outputs |
|---|---|---|---|
| LogAnalysisAgent | Parse logs, find error patterns | log_lines, service | error_patterns, severity, hypothesis |
| MetricsAgent | Detect anomalies, predict failures | Prometheus time-series | anomalies, prediction |
| RCAAgent | Correlate all signals → root cause | log + metrics + traces | root_cause, fix_steps |
| DeploymentAgent | Choose strategy, rollout, rollback | app_name, image_tag | strategy, kubectl_commands |
| SecurityAgent | Scan CVEs, auto-remediate | Trivy/Snyk results | vulnerabilities, patch_commands |
| InfraAgent | Detect + recover failed resources | CloudWatch alarms | failed_resources, terraform_commands |

## Quick Start

### Prerequisites
- Python 3.12+
- Docker & kubectl
- AWS CLI configured
- Terraform 1.6+

### Local Development

```bash
# Clone
git clone https://github.com/your-org/ai-devops-platform.git
cd ai-devops-platform

# Backend
cd backend
pip install -r requirements.txt

# Set environment variables
export ANTHROPIC_API_KEY=sk-ant-...
export LLM_PROVIDER=claude          # or openai, bedrock
export GITHUB_TOKEN=ghp_...

# Run
uvicorn main:app --reload --port 8000

# Test the chat endpoint
curl -X POST http://localhost:8000/api/v1/chat/ \
  -H "Content-Type: application/json" \
  -d '{"message": "Why did the deployment fail?"}'
```

### Docker Compose (full stack)

```bash
docker compose up -d
# Services: backend, frontend, prometheus, grafana, elasticsearch, kibana
```

### Deploy to AWS EKS

```bash
# 1. Provision infrastructure
cd terraform
terraform init
terraform plan -var-file=prod.tfvars
terraform apply

# 2. Configure kubectl
aws eks update-kubeconfig --name ai-devops-platform-eks --region us-east-1

# 3. Deploy platform
kubectl apply -f kubernetes/deployments/ai-devops-platform.yaml
kubectl apply -f monitoring/prometheus-rules.yaml

# 4. Verify
kubectl get pods -n ai-devops-platform
```

### GitHub Actions Integration

Add these secrets to your repo (`Settings → Secrets`):

| Secret | Value |
|---|---|
| `AWS_DEPLOY_ROLE_ARN` | IAM role ARN for OIDC |
| `ECR_REGISTRY` | `123456789.dkr.ecr.us-east-1.amazonaws.com` |

Add these variables:

| Variable | Value |
|---|---|
| `AI_PLATFORM_URL` | `https://ai-devops.your-domain.com` |
| `EKS_CLUSTER` | `ai-devops-platform-eks` |
| `APP_NAME` | Your application name |

Copy `pipelines/self-healing-ci.yml` to `.github/workflows/` in your app repo.

## API Reference

### ChatOps
```
POST /api/v1/chat/
Body: { "message": "string", "context": { "log_lines": [], "metrics": {} } }
Response: { "reply": "string", "sources": [], "agent_results": {} }
```

### Pipeline Failure Webhook
```
POST /api/v1/pipeline/failure
Body: { "run_id", "repo", "branch", "workflow", "failed_step", "log_lines", "attempt" }
Response: { "rca_summary", "fix_steps", "auto_retried", "retry_run_id" }
```

### Deployment Plan
```
POST /api/v1/deployment/plan
Body: { "app_name", "image_tag", "namespace", "environment" }
Response: { "strategy", "canary_weight", "kubectl_commands", "monitoring_check" }
```

### RCA Trigger
```
POST /api/v1/rca/analyze
Body: { "incident_description", "log_lines", "metrics", "traces" }
Response: { "root_cause", "fix_steps", "escalate_human", "estimated_fix_time" }
```

## Self-Healing Workflow

```
1. Deployment fails (GitHub Actions)
2. CI/CD sends POST /api/v1/pipeline/failure with logs
3. LogAnalysisAgent parses error patterns
4. RCAAgent correlates: logs + metrics + recent deployments
5. Fix plan generated with confidence score
6. If confidence ≥ 75% and not escalation-required → auto-retry
7. DeploymentAgent selects strategy → executes kubectl rollout
8. Post-deploy error rate validated via Prometheus
9. Auto-rollback if SLO breach detected
10. Slack notification with full RCA report
```

## Security

- All secrets via AWS Secrets Manager + External Secrets Operator
- Kubernetes RBAC with least-privilege service accounts
- IRSA (IAM Roles for Service Accounts) — no long-lived credentials
- Trivy + Snyk scanning on every build
- Network policies restricting pod-to-pod communication
- Read-only root filesystem on all containers

## Extending the Platform

### Add a new agent

```python
from agents.base import BaseAgent

class CostOptimizationAgent(BaseAgent):
    goal = "Detect and eliminate cloud cost waste"
    
    SYSTEM = "You are a FinOps engineer. Analyze AWS Cost Explorer data..."
    
    async def _reason(self, inputs: dict) -> dict:
        resp = await self.llm.complete(self.SYSTEM, json.dumps(inputs))
        return self._parse_json(resp)
    
    async def _act(self, analysis: dict, inputs: dict) -> list[str]:
        # Implement cost-saving actions
        ...
```

### Add a new router

```python
# backend/routers/cost.py
from fastapi import APIRouter
router = APIRouter()

@router.post("/analyze")
async def analyze_costs(req: CostRequest): ...
```

Register in `backend/main.py`:
```python
app.include_router(cost.router, prefix="/api/v1/cost", tags=["Cost Optimization"])
```

## Observability

- Prometheus scrapes all services via annotations
- Grafana dashboards: platform health, agent activity, deployment frequency
- ELK/Loki: centralized log aggregation
- OpenTelemetry traces: distributed request tracing across agents
- AlertManager → Slack/PagerDuty for critical alerts

## Tech Stack

| Layer | Technology |
|---|---|
| AI Orchestration | LangChain + Claude (Anthropic) / GPT-4 |
| Backend | FastAPI (Python 3.12) |
| Frontend | React 18 + TypeScript |
| Container | Docker |
| Orchestration | Kubernetes (EKS) |
| Deployment | Argo Rollouts (blue/green, canary) |
| IaC | Terraform (modular) |
| CI/CD | GitHub Actions |
| Monitoring | Prometheus + Grafana |
| Logging | ELK Stack / Loki |
| Tracing | OpenTelemetry |
| Security | Trivy + Snyk |
| Secrets | AWS Secrets Manager + External Secrets |
| Vector DB | FAISS / Pinecone (optional RAG) |

## License

MIT
